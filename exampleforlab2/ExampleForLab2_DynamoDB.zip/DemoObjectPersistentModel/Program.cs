﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AccessDynamoDB;
using DemoDocumentModel;

namespace DemoObjectPersistentModel
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("start dynamodb demo operations");
            // lower model 
            AccessDynamoDB.DDBOperations operation = new AccessDynamoDB.DDBOperations();
            await operation.GetAllTables();
            bool existed = await operation.TableExisted();
            if (existed)
            {
                Console.WriteLine("The Dynamodb table has been existed.");
            }
            else
            {
                await operation.CreateTable();
            }
            
            await operation.DescribeTable();
            await operation.GetAllTables();
            await operation.GetItem();
            //await operation.DeleteTable();

            // document model
            DemoDocumentModel.DDBOperation docops = new DemoDocumentModel.DDBOperation("User");
            await docops.InsertAsync();
            await docops.LoadItemAsync(1003, "yli@gmail.com");

            // orm model

            DDBOperation ops = new DDBOperation();
            await ops.CRUDOperations();

            Console.WriteLine("All operations have been finished sucessfully!");
            Console.ReadKey();
        }
    }
}
